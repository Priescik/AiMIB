For help on command-line Framsticks usage, see http://www.framsticks.com/a/text

