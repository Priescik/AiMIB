This directory contains custom neurons provided as examples.
You can see how neurons are defined using scripts.
It also contains sample experiment definitions
with interesting applications and exemplary FramScript solutions.

If you have designed your own neuron in a *.neuro
file, and you want it to be loaded when Framsticks starts,
place the file in "scripts" subdirectory. This also applies
to your *.expdef files - they should be copied to the "scripts"
subdirectory in order to be usable in Framsticks.
